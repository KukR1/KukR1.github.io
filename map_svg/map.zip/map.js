$(document).ready(function() {
$(".svgmap g,.svgmap circle").hover(function(e) {
$('#info-box').css('display','block');
$('#info-box').html($(this).data('info'));
$('#info-box').css('margin-top','-100px');
});

$(".svgmap g,.svgmap circle").mouseleave(function(e) {
$('#info-box').css('display','none');
});

$(document).mousemove(function(e) {
if( $(window).width()>=600){

$('#info-box').css('top',e.pageY-$('#info-box').height()-30);
$('#info-box').css('left',e.pageX-($('#info-box').width())/3);
}
}).mouseover();


});
